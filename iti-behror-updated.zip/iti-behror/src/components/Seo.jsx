import { useEffect } from 'react';
import { useLanguage } from '../context/LanguageContext.jsx';
import { SITE } from '../config.js';

function setMeta(attr, key, value) {
  let el = document.head.querySelector(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', value);
}

// Sets a page-specific <title> and description (plus Open Graph tags) in the
// visitor's language. `page` maps to translations: seo.<page>.title / .desc
//
// Note: these are applied by JavaScript in the browser. Google runs JavaScript,
// but many social-media link previews do not. See README ("Known limitations").
export default function Seo({ page }) {
  const { t, lang } = useLanguage();
  const title = t(`seo.${page}.title`);
  const description = t(`seo.${page}.desc`);

  useEffect(() => {
    const fullTitle = page === 'home' ? title : `${title} | ${SITE.nameEn}`;
    document.title = fullTitle;
    setMeta('name', 'description', description);
    setMeta('property', 'og:title', fullTitle);
    setMeta('property', 'og:description', description);
    setMeta('property', 'og:type', 'website');
    setMeta('property', 'og:locale', lang === 'hi' ? 'hi_IN' : 'en_IN');
    setMeta('name', 'twitter:card', 'summary');
  }, [page, title, description, lang]);

  return null;
}
