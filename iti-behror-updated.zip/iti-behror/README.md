# Government ITI Behror website

Bilingual (English / हिंदी) responsive public website built with React, Vite and React Router.
Institute location shown on the site: Dhindor, Behror, Rajasthan, India.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
npm run build
npm run preview
```

## Project notes

- The first-visit language selection (English / हिंदी) is retained and remembers the choice in the browser.
- The supplied institute logo is `public/iti-logo.png`.
- The Article page and `/articles` route have been removed. Unknown routes, including the former article URL, display the not-found page.
- Demo/sample notice cards are not rendered. The supplied admission circular is retained as reference material; its October 10–15, 2026 application window has passed, and the website warns visitors to confirm current availability.
- Trade and staff details already present in the project have been preserved. Please verify all trade, staff and eligibility information with the institute before launch.
- The footer credit is exactly `Developed by CHNM` and `Trade with help of Instructor Vishav Kumar`.
- Contact details are configured in `src/config.js` (`address`, `phone`, and `mapsSearchUrl`). The phone remains the requested `+91XXXXXXXXXX` placeholder. Update it only when the institute supplies a valid number.
- The Contact section shows an embedded Google Map of "Gov. ITI Dhindhor" plus "View on Google Maps" and "Get Directions" buttons. The embed URL and links are in `src/config.js`.
- Gallery photos live in `public/gallery/`; add a photo by copying the file there and adding one entry in `src/data/gallery.js` (shown on Home, Gallery and About pages).
- The About Us text (English and Hindi) is in `src/data/about.js`; edit the text there.
- There is currently **no admin panel, backend, or persistent settings storage** in this repository. Contact information changes must be made in `src/config.js` and redeployed.

## Before publishing

1. Replace `+91XXXXXXXXXX` with an approved public phone number when supplied.
2. About Us text in `src/data/about.js` is a draft; replace it with the institute's approved text.
3. Verify trade, staff, eligibility and admission information against current institute documents.
4. Supply current official notices and approved photographs if they should appear publicly.
5. Run `npm install`, `npm run build`, and test the built site with `npm run preview`; check desktop/mobile and both language selections.
6. Deploy the `dist/` output using the chosen hosting provider. `vercel.json` provides SPA fallback routing for Vercel.
